package main;

public class Animal {
    String animalType; 
    String animalName;
    int animalAge;

    public Animal(String animalType, String animalName, Integer animalAge) {
        this.animalType = animalType;
        this.animalName = animalName;
        this.animalAge = animalAge;
    }

    

}
